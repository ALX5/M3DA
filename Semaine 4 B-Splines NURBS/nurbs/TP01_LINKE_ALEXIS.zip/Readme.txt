Linke Alexis 

TP réalisé jusqu'à la question 12 de la première partie.
La courbe Bspline se trace correctement mais il n'y a aucun changement lors de la modification du vecteur nodal en vecteur non uniforme.

Il est possible d'ajouter des points de contrôle avec le click gauche et de réinitialiser le vecteur nodal et les points de contrôle avec le click droit.

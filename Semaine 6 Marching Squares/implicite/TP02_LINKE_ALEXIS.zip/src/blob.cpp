#include "blob.h"

Blob::Blob(){}

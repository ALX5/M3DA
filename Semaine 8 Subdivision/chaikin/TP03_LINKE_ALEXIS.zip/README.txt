Linke Alexis 

TP r�alis� jusqu'� la question 4 de la derni�re partie. 
Il y a un probl�me pour les courbes ferm�es au niveau de la liaison entre le dernier et le premier point.

Les points mobiles s'ajoutent � l'aide du clique gauche et les points fixes � l'aide du clique droit.
Il faut cliquer sur le bouton iterate pour it�rer les processus. 
